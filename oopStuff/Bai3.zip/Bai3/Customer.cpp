#include <iostream>
#include "Customer.h"
using namespace std;
//Customer class definition
Customer::Customer(const std::string name, int numpurchase, double price)
{
    SetName(name);
    SetnumPurchase(numPurchase);
    SetUnitprice(price);
}
Customer::Customer()
{
    SetName("");
    SetnumPurchase(0);
    SetUnitprice(0);
}
Customer::~Customer()
{
}
//setter and getter
void Customer::SetMoneyPay(double money)
{
    MoneyPay = money;
}
void Customer::SetnumPurchase(int n)
{
    numPurchase = n;
}
void Customer::SetUnitprice(double price)
{
    UnitPrice = price;
}
void Customer::SetName(std::string name){
    Name=name;
}
//Customer A definition
CustomerA::CustomerA()
{
}
CustomerA::CustomerA(const std::string name, int numpurchase, double price) : Customer(name, numpurchase, price)
{
    CaculateMoneyPay();
}
CustomerA::~CustomerA()
{
}
//other method
void CustomerA::CaculateMoneyPay()
{
    double money;
    money = GetnumPurchase() * GetUnitPrice() * (1 + 0.1);
    SetMoneyPay(money);
}

//CustomerB definition
//constructor and destructor
CustomerB::CustomerB()
{
    SetUsageYear(0);
    SetDiscount();
}
CustomerB::CustomerB(const std::string name, int numpurchase, double price, int year) : Customer(name, numpurchase, price)
{
    SetUsageYear(year);
}
CustomerB::~CustomerB()
{
}
//setter and getter
void CustomerB::SetUsageYear(int year)
{
    UsageYear = year;
}
void CustomerB::SetDiscount()
{
    Discount = GetUsageYear() * 5 / 100;
    if (Discount > 0.5)
    {
        Discount = 0.5;
    }
}
//other method
void CustomerB::CaculateMoneyPay()
{
    SetDiscount();
    double money;
    money = GetnumPurchase() * GetUnitPrice() * (1 - GetDiscount()) * (1 + 0.1);
    SetMoneyPay(money);
}

//CustomerC definition
//constustor and destructor
CustomerC::CustomerC(const std::string name, int numpurchase, double price):Customer(name,numpurchase,price){
}
CustomerC::CustomerC(){
}
CustomerC::~CustomerC(){
}
//other method
void CustomerC::CaculateMoneyPay(){
    double money;
    money = GetnumPurchase() * GetUnitPrice() *0.5* (1 + 0.1);
    SetMoneyPay(money);
}