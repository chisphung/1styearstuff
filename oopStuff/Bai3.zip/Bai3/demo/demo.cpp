#include<iostream>
using namespace std;
int main(){
    const int a=5;
    const int const * p=&a;
    return 0;
}