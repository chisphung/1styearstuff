#pragma once
#include <string>
#include <iostream>
#include <limits>
using namespace std;
class Customer
{
private:
    std::string Name;
    double MoneyPay;
    int numPurchase;
    double UnitPrice;

public:
    //constructor and destructor
    Customer(const std::string name, int numpurchase, double price);
    Customer();
    ~Customer();
    //setter and getter
    void SetMoneyPay(double money);
    void SetMoneyPay(double money);
    void SetName(std::string name);
    void SetnumPurchase(int n);
    void SetUnitprice(double price);
    std::string GetName() { return Name; }
    int GetnumPurchase() { return numPurchase; }
    double GetMoneyPay() { return MoneyPay; }
    double GetUnitPrice() { return UnitPrice; }
    //other method

    std::ostream &operator<<(std::ostream &os)
    {
        os << "Name: " << GetName() << std::endl;
        os << "Money have to pay: " << GetMoneyPay() << std::endl;
        return os;
    }
    virtual std::istream &operator>>(std::istream &is)
    {
        std::string name;
        is.ignore(numeric_limits<streamsize>::max(), '\n');
        getline(is, name);
        SetName(name);
        int num;
        is >> num;
        SetnumPurchase(num);
        double price;
        is >> price;
        SetUnitprice(price);
        this->CaculateMoneyPay();
        return is;
    }
    virtual void CaculateMoneyPay() = 0;
};

//normal customer
class CustomerA : public Customer
{
public:
    //constructor and destructor
    CustomerA();
    CustomerA(const std::string name, int numpurchase, double price);
    ~CustomerA();
    //other method
    virtual void CaculateMoneyPay();
};

//patron
class CustomerB : public Customer
{
private:
    int UsageYear;
    double Discount;

public:
    //constructor and destructor
    CustomerB();
    CustomerB(const std::string name, int numpurchase, double price, int year);
    ~CustomerB();
    //setter and getter
    void SetUsageYear(int year);
    void SetDiscount();
    int GetUsageYear() { return UsageYear; }
    double GetDiscount() { return Discount; }
    //other method
    std::istream &operator>>(std::istream &is)
    {
        Customer::operator>>(is);
        int year;
        is >> year;
        SetUsageYear(year);
        CaculateMoneyPay();
        return is;
    }
    virtual void CaculateMoneyPay();
};
//Vip customer
class CustomerC : public Customer
{
public:
    //constustor and destructor
    CustomerC(const std::string name, int numpurchase, double price);
    CustomerC();
    ~CustomerC();
    //other method
    virtual void CaculateMoneyPay();
};
