#include<iostream>
using namespace std;

class CDate {
private:
	int dd, mm, yy;
public:
	void setDd(int dd) {
		this->dd = dd;
	}
	void setMm(int mm) {
		this->mm = mm;
	}
	void setYy(int yy) {
		this->yy = yy;
	}
	int getDd() {
		return dd;
	}
	int getMm() {
		return mm;
	}
	int getYy() {
		return yy;
	}
	friend CDate operator+(CDate &a, int b);
	friend CDate operator-(CDate &a, int b);
	friend istream& operator >>(istream& in,CDate &a);
	friend ostream& operator <<(ostream& out, CDate a);
};
bool leapYear(int x) {
	return (x % 100 == 0 && x % 400 != 0);
}
//int days[12] = { 31, 28, 31, 30, 31, 30,
//			   31, 31, 30, 31, 30, 31 };
//int daysInMonth(int mm, int yy) {
//	if (mm == 2 && leapYear(yy)) return 29;
//	return days[mm - 1];
//}
//
//int dateToNum(int dd, int mm, int yy) {
//	int num = dd;
//	for (int i = 1; i < mm; ++i) {
//		num += daysInMonth(i, yy);
//	}
//	return num + 365 * yy + (yy / 4) - (yy / 100) + (yy / 400);
//}
//
//CDate numToDate(int num) {
//	CDate res;
//	int yy = (num * 4000 + 14780) / 3652425;
//	int ddd = num - (365 * yy + yy / 4 - yy / 100 + yy / 400);
//	if (ddd < 0) {
//		yy -= 1;
//		ddd = num - (365 * yy + yy / 4 - yy / 100 + yy / 400);
//	}
//	int mm = (100 * ddd + 52) / 3060;
//	int dd = ddd - (306 * mm + 5) / 10 + 1;
//	res.setDd(dd);
//	res.setMm(mm);
//	res.setYy(yy);
//	return res;
//}

//}
CDate operator+(CDate& a, int b) {
	a.dd += b;
	while (a.dd > 31 || (a.mm == 2 && a.dd > 29) || (a.mm == 4 || a.mm == 6 || a.mm == 9 || a.mm == 11) && a.dd > 30) {
		if (a.mm == 2 && leapYear(a.yy)) {
			a.dd -= 29;
		}
		else if (a.mm == 2) {
			a.dd -= 28;
		}
		else if (a.mm == 4 || a.mm == 6 || a.mm == 9 || a.mm == 11) {
			a.dd -= 30;
		}
		else {
			a.dd -= 31;
		}
		++a.mm;
		if (a.mm > 12) {
			a.mm = 1;
			++a.yy;
		}
	}
	return a;
}

CDate operator-(CDate& a, int b) {
	a.dd -= b;
	while (a.dd < 1 || (a.mm == 3 && a.dd < 1) || (a.mm == 1 || a.mm == 5 || a.mm == 7 || a.mm == 8 || a.mm == 10 || a.mm == 12) && a.dd < 1) {
		if (a.mm == 3 && leapYear(a.yy)) {
			a.dd += 29;
		}
		else if (a.mm == 3) {
			a.dd += 28;
		}
		else if (a.mm == 5 || a.mm == 7 || a.mm == 8 || a.mm == 10 || a.mm == 12) {
			a.dd += 30;
		}
		else {
			a.dd += 31;
		}
		--a.mm;
		if (a.mm < 1) {
			a.mm = 12;
			--a.yy;
		}
	}
	return a;
}
//CDate operator+(CDate& a, int b) {
//	int num = (a.dd, a.mm, a.yy);
//	num += b;
//	a = numToDate(num);
//	return a;
//}
//CDate operator-(CDate& a, int b) {
//	int num = (a.dd, a.mm, a.yy);
//	num -= b;
//	a = numToDate(num);
//	return a;
//}
CDate operator ++(CDate& a) {
	return a + 1;
}
CDate operator --(CDate& a) {
	return a - 1;
}
istream& operator >> (istream& in, CDate& a) {
	cout << "Nhap ngay, thang ,nam: \n ";
	in >> a.dd >> a.mm >> a.yy;
	return in;
}
ostream& operator <<(ostream& out, CDate a) {
	out << a.dd <<'/' << a.mm<<'/' << a.yy<<'\n';
	return out;
}
int main() {
	CDate a;
	cin >> a;
	int temp;
	cout << "Nhap so ngay can cong them: \n";
	cin >> temp;
	cout << a + temp;
	cout << "Nhap so ngay can tru: \n";
	cin >> temp;
	cout << a - temp;
	cout << "Ngay thang nam sau khi tang them mot ngay: \n" << ++a<<'\n';
	cout << "Ngay thang nam sau khi giam mot ngay: \n" << --a << '\n';
	return 0;
}

