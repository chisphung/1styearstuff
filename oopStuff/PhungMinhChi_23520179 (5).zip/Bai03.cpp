#include<iostream>
using namespace std;

class CTime {
private:
	int hrs, min, sec;
public:
	CTime(int hrs = 0, int min = 0, int sec = 0) {
		this->hrs = hrs;
		this->min = min;
		this->sec = sec;
	}
	void setHrs(int hrs) {
		this->hrs = hrs;
	}
	void setMin(int min) {
		this->min = min;
	}
	void setSec(int sec) {
		this->sec = sec;
	}
	int getHrs() {
		return hrs;
	}
	int getMin() {
		return min;
	}
	int getSec() {
		return sec;
	}
	friend CTime operator+(CTime &a, int b);
	friend CTime operator-(CTime &a, int b);
	friend CTime operator++(CTime &a);
	friend CTime operator--(CTime &a);
	friend istream& operator >>(istream& in, CTime& a);
	friend ostream& operator << (ostream& out, CTime a);
};
CTime operator+(CTime& a, int b) {
	a.sec += b;
	a.min += a.sec / 60;
	a.sec %= 60;
	a.hrs += a.min / 60;
	a.min %= 60;
	a.hrs %= 24;
	return a;
}

CTime operator-(CTime& a, int b) {
	int totalSeconds = a.hrs * 3600 + a.min * 60 + a.sec - b;
	if (totalSeconds < 0)
		totalSeconds += 24 * 3600;

	a.hrs = totalSeconds / 3600;
	totalSeconds %= 3600;
	a.min = totalSeconds / 60;
	a.sec = totalSeconds % 60;

	return a;
}
CTime operator++(CTime &a) {
	return a + 1;
}
CTime operator--(CTime &a) {
	return a-1;
}
istream& operator >>(istream& in, CTime& a) {
	cout << "Nhap gio, phut, giay: \n";
	in >> a.hrs >> a.min >> a.sec;
	return in;
}
ostream& operator <<(ostream& out, CTime a) {
	out << a.hrs <<' ' << a.min<<' ' << a.sec<<' ' << '\n';
	return out;
}
int main() {
	CTime a;
	cin >> a;
	cout << "Nhap so giay muon tang: ";
	int temp;
	cin >> temp;
	cout << "Thoi gian sau khi tang: " << a + temp;
	cout << "Nhap so giay muon giam";
	cin >> temp;
	cout << "Thoi gian sau khi giam: " << a - temp;
	cout << "Thoi gain sau khi tang mot don vi giay: " << ++a;
	cout << "Thoi gian sau khi giam mot don vi giay: " << --a;
}