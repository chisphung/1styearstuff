#include<iostream>
#include<math.h>
using namespace std;

class SoPhuc {
private:
	double phanthuc;
	double phanao;
public:
	SoPhuc(double phanthuc = 0, double phanao = 0) {
		this->phanthuc = phanthuc;
		this->phanao = phanao;
	}

	~SoPhuc() {}
	friend istream& operator >> (istream& in, SoPhuc& a);
	friend ostream& operator << (ostream& out, SoPhuc a);
	SoPhuc operator + (SoPhuc b) const;
	SoPhuc operator - (SoPhuc b) const;
	SoPhuc operator * (SoPhuc b) const;
	SoPhuc operator / (SoPhuc b) const;
	bool operator == (SoPhuc b) const;
	bool operator != (SoPhuc b) const;
};
istream& operator >> (istream& in, SoPhuc& a) {
	cout << "Nhap phan thuc va phan ao cua so phuc: " << endl;
	in >> a.phanthuc >> a.phanao;
	return in;
}
ostream& operator <<(ostream& out, SoPhuc a) {
	out << a.phanthuc << " + " << a.phanao << 'i';
	return out;
}
SoPhuc SoPhuc::operator+(SoPhuc b) const {
	SoPhuc temp;
	temp.phanthuc = this->phanthuc + b.phanthuc;
	temp.phanao = this->phanao + b.phanao;
	return temp;
}
SoPhuc SoPhuc::operator-(SoPhuc b) const {
	SoPhuc temp;
	temp.phanthuc = this->phanthuc - b.phanthuc;
	temp.phanao = this->phanao - b.phanao;
	return temp;
}
SoPhuc SoPhuc::operator*(SoPhuc b) const {
	SoPhuc temp;
	temp.phanthuc = this->phanthuc * b.phanthuc - this->phanao * b.phanao;
	temp.phanao = (this->phanthuc * b.phanao) + (this->phanao * b.phanthuc);
	return temp;
}
SoPhuc SoPhuc::operator/(SoPhuc b) const {
	SoPhuc temp;
	temp.phanthuc = ((this->phanthuc * b.phanthuc + this->phanao * b.phanao) / (pow(b.phanthuc, 2) + pow(b.phanao, 2)));
	temp.phanao = ((this->phanao * b.phanthuc - this->phanthuc * b.phanao) / (pow(b.phanthuc, 2) + pow(b.phanao, 2)));
	return temp;
}
bool SoPhuc::operator==(SoPhuc b) const {
	if (phanthuc == b.phanthuc && phanao == b.phanao) {
		return true;
	}
	return false;
}
bool SoPhuc::operator!=(SoPhuc b) const {
	if (phanthuc != b.phanthuc && phanao != b.phanao) {
		return true;
	}
	return false;
}
int main() {
	SoPhuc a, b;
	cin >> a >> b;
	cout << "So phuc tong: " << a + b << endl;
	cout << "So phuc hieu: " << a - b << endl;
	cout << "So phuc tich: " << a * b << endl;
	cout << "So phuc thuong: " << a / b << endl;
	if (a == b) cout << "Hai so phuc bang nhau"; else cout << "Hai so phuc khong bang nhau";

}