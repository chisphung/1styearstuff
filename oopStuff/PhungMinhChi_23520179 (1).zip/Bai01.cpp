#include<iostream>
#include<string>
using namespace std;
int nDev, nTester;
double AvgofCompany;
class Employees {
protected:
	string ID;
	string Name;
	int Age;
	int Number;
	string Email;
	int MinSalary;
	int TotalSalary;
public:
	Employees(){}
	Employees(string ID, string Name, int Age, int Number, string Email, int MinSalary) {
		this->ID = ID;
		this->Name = Name;
		this->Age = Age;
		this->Number = Number;
		this->Email = Email;
		this->MinSalary = MinSalary;
	}
	void Input() {
		cout << "Nhap ma so nhan vien: \n";
		cin.ignore();
		getline(cin, ID);
		cout << "Nhap ten nhan vien: \n";
		cin.ignore();
		getline(cin, Name);
		cout << "Nhap tuoi nhan vien: \n";
		cin >> Age; 
		cout << "Nhap SDT nhan vien: \n";
		cin >> Number;
		cout << "Nhap Email nhan vien: \n";
		cin.ignore();
		getline(cin, Email);
		cout << "Nhap luong nhan vien: \n";
		cin >> MinSalary;
	}
	void Output() {
			cout <<  ID << '\t';
			cout << Name << '\t';
			cout << Age<<'\t';
			cout <<Number<<'\t';
			cout << Email<<'\t';
			cout <<MinSalary<<'\t';
	}
};
class Devs :public Employees {
protected:
	int OT;
public:
	Devs(){}
	Devs(string ID, string Name, int Age, int Number, string Email, int MinSalary, int OT) :Employees(ID, Name, Age, Number, Email, MinSalary) {
		this->OT = OT;
	}
	void Input() {
		Employees::Input();
		cout << "Nhap so gio OT: \n";
		cin >> OT;
		TotalSalary = MinSalary + OT * 200000;
	}
	void Output() {
		Employees::Output();
		cout << OT << '\n';
	}
	int getTotalSalary() {
		return this->TotalSalary;
	}
	
};
class Tester :public Employees {
protected:
	int Bugs;
public:
	Tester(){}
	Tester(string ID, string Name, int Age, int Number, string Email, int MinSalary, int Bugs) :Employees(ID, Name, Age, Number, Email, MinSalary) {
		this->Bugs = Bugs;
	}
	void Input() {
		Employees::Input();
		cout << "Nhap so Bug: \n";
		cin >> Bugs;
		TotalSalary = MinSalary + Bugs * 50000;
	}
	void Output() {
		Employees::Output();
		cout << Bugs << '\n';
	}
	int getTotalSalary() {
		return this->TotalSalary;
	}
};

class DevList : public Devs {
private:
	Devs* a;
	double Avg;
public:
	DevList() {
		int nDev = 0;
		a = new Devs[nDev];
	}
	~DevList() {
		delete[] a;
	}
	void Input() {
		cout << "Nhap so luong lap trinh vien: ";
		cin >> nDev;
		cout << '\n';
		a = new Devs[nDev];
		for (int i = 0;i < nDev;i++) {
			cout << "Nhap thong tin nhap vien thu " << i << ": \n";
			a[i].Input();
			Avg += a[i].getTotalSalary();
		}
		Avg /= nDev;
	}
	void Ouput() {
		cout << "MSNV" << '\t' << "Ten NV" << '\t' << "Tuoi" << '\t' << "SDT" << '\t' << "Email" << '\t' << "Luong Co Ban" << '\t' << "So gio OT" << '\n';
		for (int i = 0;i < nDev;i++) {
			a[i].Output();
		}
	}
	double getAvg() {
		return Avg;
	}
	Devs* getDevList() {
		return a;
	}

};
class TesterList:public Tester {
private:
	Tester* a;
	double Avg1;
public:
	TesterList() {
		int nTester = 0;
		a = new Tester[nTester];
	}
	~TesterList() {
		delete[] a;
	}
	void Input() {
		cout << "Nhap so luong kiem chung vien: ";
		cin >> nTester;
		cout << '\n';
		a = new Tester[nTester];
		for (int i = 0;i < nTester;i++) {
			cout << "Nhap thong tin nhap vien thu " << i << ": \n";
			a[i].Input();
			Avg1 += a[i].getTotalSalary();
		}
		Avg1 /= nTester;
	}
	void Ouput() {
		cout << "MSNV" << '\t' << "Ten NV" << '\t' << "Tuoi" << '\t' << "SDT" << '\t' << "Email" << '\t' << "Luong Co Ban" << '\t' << "So Loi" << '\n';
		for (int i = 0;i < nTester;i++) {
			a[i].Output();
		}
	}
	double getAvg1() {
		return Avg1;
	}
	Tester *getTesterList() {
		return a;
	}

};
//class AvgSal: public TesterList, public DevList{
//private: 
//	int AvgSal= (getAvg() + getAvg1()) / 2;;
//public:
//	
//};
int main() {
	DevList DSDev;
	TesterList DSTester;
	cout << "Nhap danh sach lap trinh vien: \n";
	DSDev.Input();
	cout << "Nhap danh sach kiem chung vien\n";
	DSTester.Input();
	cout << "Danh sach lap trinh vien: \n";
	DSDev.Ouput();
	cout << "Danh sach kiem chung vien: \n";
	DSTester.Ouput();
	double avgofcpn = (DSDev.getAvg() + DSTester.getAvg1()) / 2;
	cout << "Luong trung binh la: " << avgofcpn << '\n';
	cout << "Lap trinh vien luong tren trung binh: \n";
	for (int i = 0;i < nTester + nDev;i++) {
		if (DSDev.getDevList()[i].getTotalSalary() < avgofcpn)
			DSDev.getDevList()[i].Output();
	}
	cout << "Kiem chung vien luong tren trung binh: \n";
	for (int i = 0;i < nTester + nDev;i++) {
		if (DSTester.getTesterList()[i].getTotalSalary() < avgofcpn)
			DSTester.getTesterList()[i].Output();
	}
	return 0;
}