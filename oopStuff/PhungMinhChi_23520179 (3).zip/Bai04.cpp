﻿#include<iostream>
#include <cmath>
using namespace std;

class CDaThuc {
private:
    int* a; 
    int n;

public:
    CDaThuc(int n = 0) {
        this->n = n;
        a = new int[n + 1]; 
        for (int i = 0; i <= n; i++) {
            a[i] = 0;
        }
    }
    ~CDaThuc() {
        delete[] a;
    }
    CDaThuc operator +(const CDaThuc& other) { 
        int maxDegree = max(n, other.n); 
        CDaThuc result(maxDegree);

        for (int i = 0; i <= maxDegree; i++) {
            if (i <= n) {
                result.a[i] += a[i];
            }
            if (i <= other.n) {
                result.a[i] += other.a[i];
            }
        }

        return result;
    }
    CDaThuc operator -(const CDaThuc& other) { 
        int maxDegree = max(n, other.n); 
        CDaThuc result(maxDegree);

        for (int i = 0; i <= maxDegree; i++) {
            if (i <= n) {
                result.a[i] += a[i];
            }
            if (i <= other.n) {
                result.a[i] -= other.a[i]; 
            }
        }

        return result;
    }
    friend istream& operator>>(istream& in, CDaThuc& a) {
        cout << "Nhap bac cua da thuc: ";
        in >> a.n;
        a.a = new int[a.n + 1];
        for (int i = a.n; i >= 0; i--) { 
            in >> a.a[i];
        }
        return in;
    }

    friend ostream& operator<<(ostream& out, const CDaThuc& a) {
        for (int i = a.n; i >= 0; i--) {
            if (a.a[i] != 0) {
                out << a.a[i];
                if (i != 0) { 
                    out << "x^" << i;
                }
                if (i != 0 && a.a[i - 1] != 0) {
                    out << " + ";
                }
            }
        }
        out << endl;
        return out;
    }


};

int main() {
    CDaThuc dt1, dt2;

    cin >> dt1 >> dt2;
    cout << dt1;
    cout << endl;
    cout << dt2;
    cout << "Tong hai da thuc: \n";
    cout << dt1 + dt2;
    cout << "Hieu hai da thuc la\n";
    cout << dt1 - dt2;
    return 0;
}
