#include<iostream>
#include<algorithm>
using namespace std;

class cHocsinh {
private:
    char mahocsinh[100];
    char hoten[100];
    char gioitinh[5];
    int namsinh;
    double Toan,Van, Anh;
    double Tong;
public:
    friend istream& operator>>(istream&in,cHocsinh& a) {
        cout << "Nhap ma hoc sinh: " << endl;
        in.ignore();
        in.getline(a.mahocsinh, 100);
        cout << "Nhap ho ten: ";
        in.getline(a.hoten, 100);
        cout << "Nhap gioi tinh: ";
        in.getline(a.gioitinh, 100);
        cout << "Nhap nam sinh: ";
        in >> a.namsinh;
        cout << "Nhap dien Toan";
        in >> a.Toan;
        cout << "Nhap diem Van";
        in >> a.Van;
        cout << "Nhap diem Anh";
        in >> a.Anh;
        a.Tong = a.Toan + a.Van + a.Anh;
        return in;
    }
    friend ostream& operator <<(ostream&out, cHocsinh &a) {
        out << a.mahocsinh << '\t' << a.hoten << '\t' << a.gioitinh << '\t' << a.namsinh << '\t' << a.Tong;
        cout << '\n';
        return out;
    }
    bool operator <(const cHocsinh& a) const { 
        return Tong < a.Tong;
    }
    bool operator >(const cHocsinh& a) const { 
        return Tong > a.Tong;
    }
    friend class cHocsinharr;
};
class cHocsinharr {
private:
    cHocsinh a[300];
    int n;
public:
    friend istream& operator>>(istream& in, cHocsinharr& a) {
        cout << "Nhap n: " << endl;
        cin >> a.n;
        for (int i = 0;i < a.n;i++) {
            cin >> a.a[i];
        } 
        return in;
    }
    friend ostream& operator<<(ostream& out, cHocsinharr a) {
        for (int i = 0;i < a.n;i++) {
            cout << a.a[i];
        }
        return out;
    }
    void SoSanh() {
        sort(a, a + n,greater <cHocsinh>());
    }
    void lonhon15() {
        cout << "Danh sach thi sinh co diem lon hon 15: \n";
        for (int i = 0;i < n;i++) {
            if (a[i].Tong > 15) cout << a[i];
        }
    }
    void caonhat() {
        cout << " Thi sinh co diem cao nhat la: \n";
        cout << a[0];
    }
};
int main() {
    cHocsinharr a;
    cin >> a;
    cout << "MSSV" << '\t' << "Ho Ten" << '\t' << "Gioi tinh" << '\t' << "Nam sinh" << '\t' << "Tong\n";
    cout << a;
    cout << endl;
    a.SoSanh();
    a.caonhat();
    a.lonhon15();
    a.caonhat();
    cout << "\n Danh sach thi sinh sau khi sap xep: \n";
    cout << a;
    return 0;
}