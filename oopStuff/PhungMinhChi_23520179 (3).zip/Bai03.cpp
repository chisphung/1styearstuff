
#include<iostream>
#include<time.h>
#include<algorithm>
#include<math.h>
#include<cstdlib> 
using namespace std;
class CSoNguyen {
private:
    int n;
    // int value=tuso/mauso;
public:
    CSoNguyen(int n = 0) {
        this->n = n;
    }
    ~CSoNguyen() {}
    int getN() {
        return n;
    }
    void SetN(int n) {
        this->n = n;
    }
    friend istream& operator>>(istream& in, CSoNguyen& songuyen);
    friend ostream& operator<<(ostream& out, CSoNguyen songuyen);
    bool operator<(const CSoNguyen& other) const {
        return n < other.n;
    }

};
istream& operator>>(istream& in, CSoNguyen& songuyen) {
    cin >> songuyen.n;
    return in;
}
ostream& operator<<(ostream& out, CSoNguyen songuyen) {
    cout << songuyen.n;
    return out;
}
class CMangSoNguyen : public CSoNguyen {
private:
    int n;
    CSoNguyen* a = new CSoNguyen[300];
public:
    CMangSoNguyen() {} 
    ~CMangSoNguyen() { 
        delete[] a;
    }
    friend ostream& operator <<(ostream& o, CMangSoNguyen a);
    void NgauNhien() {
        cout << "Nhap so luong phan tu cua mang " << endl;
        cin >> n;
        srand(time(NULL));
        for (int i = 0;i < n;i++) {
            a[i].SetN(rand() % 100 - 50);
        }
    }
    bool isPrime(int check) {
        if (check <= 1)
            return false;
        for (int i = 2; i <= sqrt(abs(check)); i++) {
            if (check % i == 0)
                return false;
        }
        return true;
    }
    // void Dem(){
    //     int count1 =0;
    //     for(int i=0;i<n;i++){
    //         if(isPrime(a[i].getN())){
    //             cout << a[i];
    //             count1++;
    //         }
    //     }
    //     cout <<endl<<"So lan xuat hien cua phan so co tu la so nguyen to la: "<< count1;
    // }
    void SoLanXuatHien(int x) {
        cout << "Nhap gia tri x";
        cin >> x;
        int count1 = 0;
        for (int i = 0;i < n;i++) {
            if (a[i].getN() == x) {} {
                count1++;
            }
        }
        cout << " So lan xuat hien cua " << x << " la: " << count1 << endl;
    }
    void Ancessding() {
        for (int i = 0;i < n;i++) {
            if (a[i] < a[i + 1]) {
                continue;
            }
            else {
                cout << "Mang khong tang dan" << endl;
                return;
            }
        }
        cout << "Mang tang dan" << endl;
    }
    void SapXep() {
        sort(a, a + n);
        cout << "Phan tu le nho nhat la: " << endl;
        for (int i = 0;i < n;i++) {
            if (a[i].getN() & 1) cout << a[i] << endl;
            break;
        }
        cout << "Phan tu la so nguyen to lon nhat la: " << endl;
        for (int i = n;i >= 0;i--) {
            if (isPrime(a[i].getN())) {
                cout << a[i] << endl;
                break;
            }
        }
    }
};
ostream& operator <<(ostream& o, CMangSoNguyen a) {
    cout << endl << "Mang hien tai la: ";
    for (int i = 0;i < a.n;i++) {
        cout << a.a[i] << " ";
    }
    return o;
}
int main() {
    CMangSoNguyen phanso;
    phanso.NgauNhien();
    cout << phanso;
    cout << endl;
    phanso.SoLanXuatHien(0);
    phanso.SapXep();
    phanso.Ancessding();
    cout << endl << "Mang da duoc sap xep la: " << endl;
    cout << phanso;
    return 0;
}