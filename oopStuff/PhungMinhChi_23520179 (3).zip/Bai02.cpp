#include<iostream>
#include<math.h>
#include<algorithm>
using namespace std;

class PhanSo {
private:
	int tuso;
	int mauso;
public:
	PhanSo(int tuso = 0, int mauso = 1) {
		this->tuso = tuso;
		this->mauso = mauso;
	}
	friend istream& operator>>(istream& in, PhanSo &ps);
	friend ostream& operator<<(ostream& out, PhanSo ps);
	bool operator<(const PhanSo& ps) const;
	PhanSo operator+(PhanSo ps);
};

istream& operator >>(istream& in, PhanSo& ps) {
	cout << "Nhap phan so: " << endl;
	in >> ps.tuso >> ps.mauso;
	return in;
}
ostream& operator <<(ostream& out, PhanSo ps) {
	out << ps.tuso << '/' << ps.mauso << endl;
	return out;
}
bool PhanSo::operator<(const PhanSo& ps) const{
	return (tuso / mauso) < (ps.tuso / ps.mauso);
}
PhanSo PhanSo::operator+(PhanSo ps) {
	PhanSo tong;
	tong.tuso = tuso * ps.mauso + ps.tuso * mauso;
	tong.mauso = mauso * ps.mauso;
	return tong;
}
class DSPhanSo {
private:
	PhanSo *a = new PhanSo [300];
	int n;
public:
	void input();
	void tong();
	void SapXep();
	friend istream& operator>>(istream& in, DSPhanSo ps);
};
istream& operator>>(istream& in, DSPhanSo ps) {
	cout << "Nhap so luong phan so: " << endl;
	cin >> ps.n;
	cout << "Nhap phan so: " << endl;
	for (int i = 0;i < ps.n;i++) {
		cin >> ps.a[i];
	}
	return in;
}
void DSPhanSo::input() {
	cout << "Nhap so luong phan so: " << endl;
	cin >> n;
	cout << "Nhap phan so: " << endl;
	for (int i = 0;i < n;i++) {
		cin >> a[i];
	}
}
void DSPhanSo::tong() {
	PhanSo tong;
	for (int i = 0;i < n;i++) {
		tong = tong+ a[i];
	}
	cout << "Tong cac phan so la: " << endl;
	cout << tong;
}
void DSPhanSo::SapXep() {
	sort(a, a + n);
	cout << "Danh sach sau khi sap xep tang dan la: " << endl;
	for (int i = 0;i < n;i++) {
		cout << a[i]<<' ';
	}
	PhanSo min = a[0];
	PhanSo max = a[n - 1];
	cout << "Danh sach sau khi sap xep giam dan la: " << endl;
	for (int i = n-1;i >=0 ;i--) {
		cout << a[i] << ' ';
	}
	cout << "Phan so lon nhat la: " << max;
	cout << endl << "Phan so nho nhat la: " << min << endl;
}
int main() {
	DSPhanSo a;
	a.input();
	a.tong();
	a.SapXep();
}