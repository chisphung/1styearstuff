#include <iostream>
#include <algorithm>
using namespace std;

class PhanSo {
private:
    int tuso;
    int mauso;
public:
    PhanSo(int tuso = 0, int mauso = 1) {
        this->tuso = tuso;
        this->mauso = mauso;
    }
    friend istream& operator>>(istream& in, PhanSo& ps);
    friend ostream& operator<<(ostream& out, PhanSo ps);
    bool operator<(const PhanSo& ps) const;
    PhanSo operator+(const PhanSo& ps);
    PhanSo& operator++();
    PhanSo operator++(int);
    PhanSo& operator--();
    PhanSo operator--(int);
};

istream& operator>>(istream& in, PhanSo& ps) {
    cout << "Nhap tu so: ";
    in >> ps.tuso;
    cout << "Nhap mau so: ";
    in >> ps.mauso;
    return in;
}

ostream& operator<<(ostream& out, PhanSo ps) {
    out << ps.tuso << '/' << ps.mauso;
    return out;
}

bool PhanSo::operator<(const PhanSo& ps) const {
    return (tuso * ps.mauso) < (mauso * ps.tuso);
}

PhanSo PhanSo::operator+(const PhanSo& ps) {
    PhanSo tong;
    tong.tuso = tuso * ps.mauso + ps.tuso * mauso;
    tong.mauso = mauso * ps.mauso;
    return tong;
}

PhanSo& PhanSo::operator++() {
    tuso += mauso;
    return *this;
}

PhanSo PhanSo::operator++(int) {
    PhanSo temp = *this;
    tuso += mauso;
    return temp;
}

PhanSo& PhanSo::operator--() {
    tuso -= mauso;
    return *this;
}

PhanSo PhanSo::operator--(int) {
    PhanSo temp = *this;
    tuso -= mauso;
    return temp;
}

class DSPhanSo {
private:
    PhanSo a[300];
    int n;
public:
    void input();
    void tong();
    void SapXep();
    friend istream& operator>>(istream& in, DSPhanSo& ps);
    friend ostream& operator<<(ostream& out, const DSPhanSo& ps);
    PhanSo& operator[](int index);
    DSPhanSo& operator++();
    DSPhanSo operator++(int);
    DSPhanSo& operator--();
    DSPhanSo operator--(int);
};

istream& operator>>(istream& in, DSPhanSo& ps) {
    cout << "Nhap so luong phan so: ";
    in >> ps.n;
    cout << "Nhap cac phan so:" << endl;
    for (int i = 0; i < ps.n; i++) {
        in >> ps.a[i];
    }
    return in;
}

ostream& operator<<(ostream& out, const DSPhanSo& ps) {
    out << "Danh sach cac phan so: ";
    for (int i = 0; i < ps.n; i++) {
        out << ps.a[i] << ' ';
    }
    return out;
}

PhanSo& DSPhanSo::operator[](int index) {
    return a[index];
}

DSPhanSo& DSPhanSo::operator++() {
    for (int i = 0; i < n; i++) {
        ++a[i];
    }
    return *this;
}

DSPhanSo DSPhanSo::operator++(int) {
    DSPhanSo temp = *this;
    ++(*this);
    return temp;
}

DSPhanSo& DSPhanSo::operator--() {
    for (int i = 0; i < n; i++) {
        --a[i];
    }
    return *this;
}

DSPhanSo DSPhanSo::operator--(int) {
    DSPhanSo temp = *this;
    --(*this);
    return temp;
}

int main() {
    DSPhanSo ps;
    cin >> ps;
    cout << ps << endl;
    cout << "Sau khi tang moi phan so trong danh sach len 1 don vi:" << endl;
    ++ps;
    cout << ps << endl;
    cout << "Sau khi giam moi phan so trong danh sach xuong 1 don vi:" << endl;
    --ps;
    cout << ps << endl;
    return 0;
}
