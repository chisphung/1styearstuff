﻿#include <iostream>
#include <vector>
#include <cstdlib> 
#include <ctime>

using namespace std;

class Matrix {
private:
    int m, n;
    vector<vector<int>> data;

public:
    Matrix(int m, int n) : m(m), n(n) {
        data.resize(m, vector<int>(n, 0));
    }

    void randomize() {
        srand(time(NULL));
        for (int i = 0; i < m; ++i) {
            for (int j = 0; j < n; ++j) {
                data[i][j] = rand() % 10;
            }
        }
    }

    friend istream&operator >>(istream&in,Matrix &a) {
        cout << "Nhap gia tri cho ma tran " << a.m << "x" << a.n << ":\n";
        for (int i = 0; i < a.m; ++i) {
            cout << "Hang " << i + 1 << ":\n";
            for (int j = 0; j < a.n; ++j) {
                cout << "Nhap gia tri tai vi tri [" << i << "][" << j << "]: ";
                in >> a.data[i][j];
            }
        }
        return in;
    }

    Matrix operator+(const Matrix& other) const {
        if (m != other.m || n != other.n) {
            cerr << "Hai ma tran khong cung kich thuoc, khong the thuc hien phep cong.\n";
            exit(1);
        }

        Matrix result(m, n);
        for (int i = 0; i < m; ++i) {
            for (int j = 0; j < n; ++j) {
                result.data[i][j] = data[i][j] + other.data[i][j];
            }
        }
        return result;
    }

    Matrix operator*(const Matrix& other) const {
        // Operator nhân hai ma trận
        if (n != other.m) {
            cerr << "So cot cua ma tran thu nhat khong bang so hang cua ma tran thu hai, khong the thuc hien phep nhan.\n";
            exit(1);
        }

        Matrix result(m, other.n);
        for (int i = 0; i < m; ++i) {
            for (int j = 0; j < other.n; ++j) {
                for (int k = 0; k < n; ++k) {
                    result.data[i][j] += data[i][k] * other.data[k][j];
                }
            }
        }
        return result;
    }

    friend ostream& operator << (ostream&out,Matrix a) {
        out << "Ma tran " << a.m << "x" << a.n << ":\n";
        for (int i = 0; i < a.m; ++i) {
            for (int j = 0; j < a.n; ++j) {
                out << a.data[i][j] << " ";
            }
            out << endl;
        }
        return out;
    }
};

int main() {
    int m, n;
    cout << "Nhap so hang cua hai ma tran: ";
    cin >> m;
    cout << "Nhap so cot cua hai ma tran: ";
    cin >> n;
    Matrix A(m, n), B(m, n);
    A.randomize();
    B.randomize();
    Matrix Tong = A + B;
    Matrix Tich = A * B;
    cout << "Ma tran A:\n";
    cout << A;
    cout << "Ma tran B:\n";
    cout << B;
    cout << "Tong hai ma tran:\n";
    cout << Tong;
    cout << "Tich hai ma tran:\n";
    cout << Tich;

    return 0;
}
